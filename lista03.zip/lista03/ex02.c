#include <stdio.h>

int main() {
    int numeros[5];
    int i;
    
    printf("digite 5 numeros inteiros:\n");
    for (i = 0; i < 5; i++) {
        printf("numero %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }
    
    printf("\nnumeros maiores que 10:\n");
    for (i = 0; i < 5; i++) {
        if (numeros[i] > 10) {
            printf("%d\n", numeros[i]);
        }
    }
    
    return 0;
}