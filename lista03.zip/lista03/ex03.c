#include <stdio.h>

int main() {
    int matriz[2][2];
    int i, j;
    
    printf("digite os elementos da matriz 2x2:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }
    
    int maior_elemento = matriz[0][0];
    
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            if (matriz[i][j] > maior_elemento) {
                maior_elemento = matriz[i][j];
            }
        }
    }
    
    printf("\nmatriz digitada:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
    
    printf("\no maior elemento da matriz e: %d\n", maior_elemento);
    
    return 0;
}