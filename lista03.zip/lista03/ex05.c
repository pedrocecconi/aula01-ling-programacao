#include <stdio.h>

int main() {
    int matriz[2][3];
    int i, j;
    int contador_maior_cinco = 0;
    
    printf("digite os elementos da matriz 2x3:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            printf("elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }
    
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            if (matriz[i][j] > 5) {
                contador_maior_cinco++;
            }
        }
    }
    
    printf("\nmatriz digitada:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }
    
    printf("\nnumero de elementos maiores que 5: %d\n", contador_maior_cinco);
    
    return 0;
}