#include <stdio.h>

int main() {
    int matriz[3][3];
    int i, j;
    int soma_diagonal = 0;
    
    printf("digite os elementos da matriz 3x3:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }
    
    for (i = 0; i < 3; i++) {
        soma_diagonal += matriz[i][i];
    }
    
    printf("\nmatriz digitada:\n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
    
    printf("\nsoma da diagonal principal: %d\n", soma_diagonal);
    
    return 0;
}