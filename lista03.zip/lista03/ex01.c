#include <stdio.h>

int main() {
    float numeros[4];
    float soma = 0;
    int i;
    
    printf("digite 4 numeros:\n");
    for (i = 0; i < 4; i++) {
        printf("numero %d: ", i + 1);
        scanf("%f", &numeros[i]);
        soma += numeros[i];
    }
    
    float media = soma / 4.0;
    
    printf("a soma dos numeros e: %.2f\n", soma);
    printf("a media dos numeros e: %.2f\n", media);
    
    return 0;
}