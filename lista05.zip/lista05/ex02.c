//Calculadora de numeros.

#include <stdio.h>

int main() {
    int numeros[10];
    int pares_e_positivos = 0;
    int impares_ou_negativos = 0;
    int multiplos_de_3_e_5 = 0;

    printf("Digite 10 numeros inteiros:\n");

    for (int i = 0; i < 10; i++) {
        printf("Numero %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    for (int i = 0; i < 10; i++) {
        if (numeros[i] % 2 == 0 && numeros[i] > 0) {
            pares_e_positivos++;
        }

        if (numeros[i] % 2 != 0 || numeros[i] < 0) {
            impares_ou_negativos++;
        }

        if (numeros[i] % 3 == 0 && numeros[i] % 5 == 0) {
            multiplos_de_3_e_5++;
        }
    }

    printf("\n=== Contagem de Numeros ===\n");
    printf("Pares e positivos: %d\n", pares_e_positivos);
    printf("Impares ou negativos: %d\n", impares_ou_negativos);
    printf("Multiplos de 3 e de 5: %d\n", multiplos_de_3_e_5);

    return 0;
}