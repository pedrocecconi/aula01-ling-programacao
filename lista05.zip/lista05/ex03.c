//Sistema de avaliaçao escolar

#include <stdio.h>

int main() {
    float matriz[5][4];
    float medias[5];
    float soma_notas;
    float maior_media = -1.0;
    float menor_media = 11.0;
    int aluno_maior_media = -1;
    int aluno_menor_media = -1;

    printf("--- Sistema de Avaliacao Escolar ---\n");

    for (int i = 0; i < 5; i++) {
        printf("\nNotas do Aluno %d:\n", i + 1);
        soma_notas = 0;
        for (int j = 0; j < 4; j++) {
            printf("  Bimestre %d: ", j + 1);
            scanf("%f", &matriz[i][j]);
            soma_notas += matriz[i][j];
        }
        medias[i] = soma_notas / 4.0;
    }

    for (int i = 0; i < 5; i++) {
        if (medias[i] > maior_media) {
            maior_media = medias[i];
            aluno_maior_media = i + 1;
        }
        if (medias[i] < menor_media) {
            menor_media = medias[i];
            aluno_menor_media = i + 1;
        }
    }

    printf("\n--- Relatorio de Desempenho ---\n");

    for (int i = 0; i < 5; i++) {
        const char *status = (medias[i] >= 7.0) ? "Aprovado" :
                             (medias[i] >= 5.0) ? "Recuperacao" : "Reprovado";
        
        printf("\nAluno %d:\n", i + 1);
        printf("  Media: %.2f\n", medias[i]);
        printf("  Status: %s\n", status);
    }

    printf("\n--- Estatisticas da Turma ---\n");
    printf("Aluno com maior media: Aluno %d (Media: %.2f)\n", aluno_maior_media, maior_media);
    printf("Aluno com menor media: Aluno %d (Media: %.2f)\n", aluno_menor_media, menor_media);

    return 0;
}