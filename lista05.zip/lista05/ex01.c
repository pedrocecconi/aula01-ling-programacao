//Calculadora de descontos

#include <stdio.h>

int main() {
    float precos[5];
    float desconto, preco_final;

    printf("Digite 5 precos de produtos:\n");

    for (int i = 0; i < 5; i++) {
        printf("Preco %d: ", i + 1);
        scanf("%f", &precos[i]);
    }

    printf("\n=== APLICANDO OS DESCONTOS ===\n");
    
    for (int i = 0; i < 5; i++) {
        desconto = 0;
        preco_final = precos[i];

        if (precos[i] > 100.00) {
            desconto = precos[i] * 0.10;
        }
        else if (precos[i] >= 50.00 && precos[i] <= 100.00) {
            desconto = precos[i] * 0.05;
        }
        else {
            desconto = 0;
        }

        preco_final = precos[i] - desconto;

        printf("\nproduto %d:\n", i + 1);
        printf("preco original: R$ %.2f\n", precos[i]);
        printf("desconto aplicado: R$ %.2f\n", desconto);
        printf("preco final: R$ %.2f\n", preco_final);
    }

    return 0;
}