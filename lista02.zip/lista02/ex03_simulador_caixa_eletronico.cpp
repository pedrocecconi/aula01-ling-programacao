//Simulador de caixa eletronico

#include <stdio.h>

int main() {
    float saldo = 1000.0;
    int opcao;
    
    do {
        // Menu de op��es
        printf("\n--- CAIXA ELETR�NICO ---\n");
        printf("1. Consultar saldo\n");
        printf("2. Realizar deposito\n");
        printf("3. Realizar saque\n");
        printf("4. Transferencia\n");
        printf("5. Sair\n");
        printf("Escolha uma op��o: ");
        scanf("%d", &opcao);
        
        switch (opcao) {
            case 1: // Consultar saldo
                printf("Saldo atual: R$ %.2f\n", saldo);
                break;
                
            case 2: { // Dep�sito
                float valor;
                printf("Valor do deposito: R$ ");
                scanf("%f", &valor);
                
                if (valor <= 0.01) {
                    printf("Erro: Valor minimo R$ 0.01\n");
                } else {
                    saldo += valor;
                    printf("Deposito realizado! Novo saldo: R$ %.2f\n", saldo);
                }
                break;
            }
                
            case 3: { // Saque
                float valor;
                printf("Valor do saque: R$ ");
                scanf("%f", &valor);
                
                if (valor > 500) {
                    printf("Erro: Limite por saque � R$ 500.00\n");
                } else if (valor > saldo) {
                    printf("Erro: Saldo insuficiente\n");
                } else {
                    saldo -= valor;
                    printf("Saque realizado! Novo saldo: R$ %.2f\n", saldo);
                }
                break;
            }
                
            case 4: { // Transfer�ncia
                float valor, taxa;
                printf("Valor da transfer�ncia: R$ ");
                scanf("%f", &valor);
                
                // Calcular taxa (minimo R$ 2.00)
                taxa = valor * 0.01;
                if (taxa < 2) taxa = 2;
                
                if (valor + taxa > saldo) {
                    printf("Erro: Saldo insuficiente para transferencia + taxa\n");
                } else {
                    saldo -= (valor + taxa);
                    printf("Transfer�ncia realizada! Taxa: R$ %.2f\n", taxa);
                    printf("Novo saldo: R$ %.2f\n", saldo);
                }
                break;
            }
                
            case 5: // Sair
                printf("Encerrando...\n");
                break;
                
            default:
                printf("Op��o invalida!\n");
        }
    } while (opcao != 5);
    
    return 0;
}
