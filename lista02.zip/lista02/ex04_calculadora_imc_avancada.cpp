//calculadora IMC avan�ada

#include <stdio.h>
#include <ctype.h>

int main() {
    float peso, altura, imc;
    int idade;
    char sexo;
    
    printf("peso (kg): ");
    scanf("%f", &peso);
    if (peso <= 0) {
        printf("erro: peso invalido.\n");
        return 1;
    }
    
    printf("altura (m): ");
    scanf("%f", &altura);
    if (altura <= 0) {
        printf("erro: altura invalida.\n");
        return 1;
    }
    
    printf("idade: ");
    scanf("%d", &idade);
    if (idade <= 0) {
        printf("erro: idade invalida.\n");
        return 1;
    }
    
    printf("sexo (m/f): ");
    scanf(" %c", &sexo);
    sexo = tolower(sexo);
    
    imc = peso / (altura * altura);
    
    printf("\nimc: %.2f - classificacao: ", imc);
    
    if (imc < 18.5) {
        printf("abaixo do peso\n");
        if (idade >= 60) {
            printf("recomendacao: consulte um geriatra\n");
        }
    } else if (imc < 25) {
        printf("peso normal\n");
    } else if (imc < 30) {
        printf("sobrepeso\n");
        if (sexo == 'm') printf("recomendacao: exercicios de forca\n");
        if (sexo == 'f') printf("recomendacao: exercicios aerobicos\n");
    } else if (imc < 35) {
        printf("obesidade grau i\n");
        if (sexo == 'm') printf("recomendacao: exercicios de forca\n");
        if (sexo == 'f') printf("recomendacao: exercicios aerobicos\n");
        if (idade <= 25) printf("recomendacao: procure um nutricionista\n");
    } else if (imc < 40) {
        printf("obesidade grau ii\n");
        if (sexo == 'm') printf("recomendacao: exercicios de forca\n");
        if (sexo == 'f') printf("recomendacao: exercicios aerobicos\n");
        if (idade <= 25) printf("recomendacao: procure um nutricionista\n");
    } else {
        printf("obesidade grau iii\n");
        if (sexo == 'm') printf("recomendacao: exercicios de forca\n");
        if (sexo == 'f') printf("recomendacao: exercicios aerobicos\n");
        if (idade <= 25) printf("recomendacao: procure um nutricionista\n");
    }
    
    return 0;
}
