//Exerc�cio 01 - Sistema de pontua��o de jogo

#include <stdio.h>

int main() {
    int pontuacao_inicial, pontuacao_atual, diferenca;
    
    // Solicitar e validar pontua��o inicial
    printf("Digite a pontua��o inicial (inteiro positivo): ");
    scanf("%d", &pontuacao_inicial);
    
    if (pontuacao_inicial <= 0) {
        printf("Erro: Pontua��o inicial deve ser positiva.\n");
        return 1;
    }
    
    pontuacao_atual = pontuacao_inicial;
    
    // Aplicar eventos sequenciais
    pontuacao_atual += 50; // Ganhou uma fase
    printf("Ap�s ganhar fase: %d\n", pontuacao_atual);
    
    pontuacao_atual *= 2; // Coletou item especial
    printf("Ap�s coletar item: %d\n", pontuacao_atual);
    
    pontuacao_atual -= 30; // Perdeu uma vida
    printf("Ap�s perder vida: %d\n", pontuacao_atual);
    
    pontuacao_atual += 15; // B�nus de tempo
    printf("Ap�s b�nus tempo: %d\n", pontuacao_atual);
    
    pontuacao_atual /= 3; // Penalidade por dificuldade
    printf("Ap�s penalidade: %d\n", pontuacao_atual);
    
    pontuacao_atual += 100; // B�nus final
    printf("Ap�s b�nus final: %d\n", pontuacao_atual);
    
    // Calcular diferen�a e exibir resultados
    diferenca = pontuacao_atual - pontuacao_inicial;
    printf("\nPontua��o Inicial: %d\n", pontuacao_inicial);
    printf("Pontua��o Final: %d\n", pontuacao_atual);
    printf("Diferen�a: %d\n", diferenca);
    
    return 0;
}
