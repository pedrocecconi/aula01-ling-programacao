//Exercicio 02 - Calculadora de notas e conceitos

#include <stdio.h>

int main() {
    float nota1, nota2, nota3, media, frequencia;
    
    // Entrada de dados com valida��o
    printf("Digite as 3 notas (0-10):\n");
    scanf("%f %f %f", &nota1, &nota2, &nota3);
    
    if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10 || nota3 < 0 || nota3 > 10) {
        printf("Erro: Notas devem estar entre 0 e 10.\n");
        return 1;
    }
    
    printf("Digite a frequencia (0-100%%): ");
    scanf("%f", &frequencia);
    
    if (frequencia < 0 || frequencia > 100) {
        printf("Erro: Frequencia invalida.\n");
        return 1;
    }
    
    // Calculo da media
    media = (nota1 + nota2 + nota3) / 3;
    
    // Determinar conceito
    char conceito;
    if (media >= 9) conceito = 'A';
    else if (media >= 7) conceito = 'B';
    else if (media >= 5) conceito = 'C';
    else conceito = 'D';
    
    // Verificar aprova��o
    printf("\nMedia: %.2f\n", media);
    printf("Conceito: %c\n", conceito);
    
    if (media >= 5 && frequencia >= 75) {
        printf("Status: Aprovado!\n");
    } else {
        printf("Status: Reprovado\n");
        if (media < 5 && frequencia < 75) {
            printf("Motivo: Nota e frequencia insuficientes\n");
        } else if (media < 5) {
            printf("Motivo: Nota insuficiente\n");
        } else {
            printf("Motivo: Frequencia insuficiente\n");
        }
    }
    
    return 0;
}
