#include<stdio.h>



int main() {
    float salario = 2500.00;
    float *ponteiro_salario;

    printf("Valor do saslario: %.2f\n", salario);
    ponteiro_salario = &salario;
    printf("Valor do salario atraves do ponteiro: %.2f\n", *ponteiro_salario);

    *ponteiro_salario = 3000.00;
    printf("Valor do salario apos alteracao atraves do ponteiro: %.2f\n", salario);
    return 0;
}