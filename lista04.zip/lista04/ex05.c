#include <stdio.h>


void inverter_string(char *str) {
    char *ponteiro_inicio = str;
    char *ponteiro_fim = str;
    char temp;


    while (*ponteiro_fim != '\0') {
        ponteiro_fim++;
    }
    ponteiro_fim--;

    
    while (ponteiro_fim > ponteiro_inicio) {
        
        temp = *ponteiro_inicio;
        *ponteiro_inicio = *ponteiro_fim;
        *ponteiro_fim = temp;

        ponteiro_inicio++;
        ponteiro_fim--;
    }
}

int main() {
    char texto[] = "TESTE PARA INVERTER STRING";
    printf("String original: %s\n", texto);
    
    inverter_string(texto);
    
    printf("String invertida: %s\n", texto);

    return 0;
}