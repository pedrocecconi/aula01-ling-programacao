#include <stdio.h>

int encontrar_maior(int *array, int tamanho) {
    // Dica: use um ponteiro para percorrer o array
    // e outro para guardar o endereço do maior elemento
    int *ponteiro_maior = array; // Assume que o primeiro elemento é o maior
    int *ponteiro_atual = array + 1; // Começa a percorrer a partir do segundo elemento

    for (int i = 1; i < tamanho; i++) {
        if (*ponteiro_atual > *ponteiro_maior) {
            ponteiro_maior = ponteiro_atual;
        }
        ponteiro_atual++;
    }

    return *ponteiro_maior;
}

int main() {
    int numeros[] = {45, 23, 78, 12, 67, 34, 89, 56};
    int tamanho = sizeof(numeros) / sizeof(numeros[0]);
    int maior;

    maior = encontrar_maior(numeros, tamanho);

    printf("numeros: ");
    for(int i=0; i < tamanho; i++) {
        printf("%d ", numeros[i]);
    }

    printf("\nmaior numero: %d\n", maior);

    return 0;
}